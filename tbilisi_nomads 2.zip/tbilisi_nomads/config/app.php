<?php
// config.php — shared DB connector
function db() {
    static $pdo = null;
    if ($pdo === null) {
        $path = __DIR__ . '/data/db.sqlite';
        $pdo = new PDO('sqlite:' . $path);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    return $pdo;
}
?>
