<?php
// /api/cost.php
require_once __DIR__ . '/../config.php';
$pdo = db();
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    echo json_encode($pdo->query('SELECT * FROM costs')->fetchAll(PDO::FETCH_ASSOC));
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    if ($data && isset($data['item'],$data['cost'])) {
        $stmt = $pdo->prepare('INSERT INTO costs(item,cost) VALUES(?,?)');
        $stmt->execute([$data['item'], $data['cost']]);
        echo json_encode(['status'=>'ok']);
    } else {
        http_response_code(400);
        echo json_encode(['error'=>'Invalid JSON']);
    }
}
?>
