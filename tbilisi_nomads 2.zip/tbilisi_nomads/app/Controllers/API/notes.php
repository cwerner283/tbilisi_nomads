<?php
// /api/notes.php
require_once __DIR__ . '/../config.php';
$pdo = db();
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    echo json_encode($pdo->query('SELECT * FROM notes ORDER BY created_at DESC')->fetchAll(PDO::FETCH_ASSOC));
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    if ($data && isset($data['name'],$data['message'])) {
        $stmt = $pdo->prepare('INSERT INTO notes(name,message) VALUES(?,?)');
        $stmt->execute([$data['name'],$data['message']]);
        echo json_encode(['status'=>'ok']);
    } else {
        http_response_code(400);
        echo json_encode(['error'=>'Invalid JSON']);
    }
}
?>
