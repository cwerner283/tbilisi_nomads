<!-- /public/partials/header.php -->
<nav
  class="sticky top-0 z-40 backdrop-blur bg-gray-900/70 border-b border-gray-800"
>
  <div
    class="max-w-5xl mx-auto px-4 py-3 flex flex-wrap items-center justify-between"
  >
    <!-- Brand -->
    <a
      href="/index.php"
      class="text-lg sm:text-xl font-bold tracking-tight text-white"
    >
      Tbilisi&nbsp;Nomads
    </a>

    <!-- Links -->
    <div class="flex gap-4 text-sm">
      <a href="/cost.php"      class="link-nav">Cost</a>
      <a href="/jobs.php"      class="link-nav">Jobs</a>
      <a href="/hoods.php"     class="link-nav">Neighborhoods</a>
      <a href="/community.php" class="link-nav">Community</a>
      <a href="/events.php"    class="link-nav">Events</a>
    </div>
  </div>
</nav>

<!-- tiny Tailwind component helper -->
<style>
  .link-nav {
    @apply text-gray-300 hover:text-white transition-colors;
  }
</style>
