<?php
require_once __DIR__ . '/../config.php';
$pdo    = db();
$events = $pdo->query('SELECT * FROM events ORDER BY event_date')
              ->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Events & Meetups – Tbilisi Nomads</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
  <style>
    @keyframes pulse {
      0% { transform: scale(1); }
      50% { transform: scale(1.05); }
      100% { transform: scale(1); }
    }
    .pulse:hover {
      animation: pulse 0.3s ease-in-out;
    }
    @keyframes bounce {
      0%, 100% { transform: translateY(0); }
      50% { transform: translateY(-5px); }
    }
    .bounce:hover {
      animation: bounce 0.4s ease-in-out;
    }
    .parallax {
      background-attachment: fixed;
      background-position: center;
      background-repeat: no-repeat;
      background-size: cover;
    }
  </style>
</head>
<body class="bg-gray-900 text-white font-sans" x-data="{ search: '', type: '', location: '' }">

<?php include __DIR__.'/partials/header.php'; ?>  <!-- nav bar -->

<!-- ===== Hero CTA ===== -->
<section class="parallax bg-[url('https://images.unsplash.com/photo-1576251437505-0fd15316ecca')] bg-cover bg-center">
  <div class="backdrop-brightness-50 py-20">
    <div class="max-w-4xl mx-auto text-center px-6">
      <h1 class="text-5xl sm:text-6xl font-extrabold mb-6 tracking-tight">
        Tbilisi Events <span class="text-amber-400">🔥 Go Wild</span>
      </h1>
      <p class="text-xl sm:text-2xl text-gray-200 mb-10 leading-relaxed">
        Bassiani raves, babushka feasts, Rustaveli art walks—join <span class="font-bold text-white">37,756+</span> nomads for Tbilisi’s wildest meetups. Sulfur baths to khinkali contests, we’ve got it all. <span class="text-amber-400">Gagimarjos!</span>
      </p>
      <a href="https://t.me/+TbilisiNomads" target="_blank" class="bg-amber-500 hover:bg-amber-400 px-10 py-5 rounded-lg font-bold text-gray-900 pulse text-lg">
        Join Telegram for Events →
      </a>
    </div>
  </div>
</section>

<!-- ===== Hot Picks ===== -->
<section class="max-w-5xl mx-auto px-6 py-12" x-data="{ picks: [
  { title: 'Bassiani After-Hours', img: 'https://picsum.photos/seed/bassiani/400/300', date: '2025-07-12', location: 'Bassiani Club', type: 'Nightlife', desc: 'Crack the door code for Tbilisi’s techno mecca. #Nightlife vibes.' },
  { title: 'Babushka Supper Club', img: 'https://picsum.photos/seed/babushka/400/300', date: '2025-07-15', location: 'Old Tbilisi', type: 'Foodie', desc: 'Eat like family with khachapuri and wine. #Foodies unite.' },
  { title: 'Rustaveli Art Walk', img: 'https://picsum.photos/seed/rustaveli/400/300', date: '2025-07-20', location: 'Rustaveli Ave', type: 'Culture', desc: 'Street art and protest vibes. #LocalVibes crew.' }
], current: 0 }" x-init="setInterval(() => current = (current + 1) % picks.length, 5000)">
  <h2 class="text-3xl font-bold text-center mb-8">Hot Picks 🔥 Nomad Must-Dos</h2>
  <div class="bg-gray-800 rounded-xl p-6">
    <div class="flex flex-col sm:flex-row gap-6">
      <img :src="picks[current].img" :alt="picks[current].title" class="w-full sm:w-1/3 h-48 object-cover rounded-lg">
      <div class="flex-1">
        <h3 class="text-xl font-semibold mb-2" x-text="picks[current].title"></h3>
        <p class="text-sm text-gray-400 mb-2">
          📅 <span x-text="picks[current].date"></span> •
          📍 <span x-text="picks[current].location"></span> •
          <span x-text="picks[current].type"></span>
        </p>
        <p class="text-gray-200" x-text="picks[current].desc"></p>
        <a href="https://t.me/+TbilisiNomads" target="_blank" class="mt-4 inline-block bg-amber-500 hover:bg-amber-400 px-6 py-2 rounded-lg font-bold text-gray-900 pulse">
          Get Details on Telegram →
        </a>
      </div>
    </div>
  </div>
</section>

<!-- ===== Nomad Fixes ===== -->
<section class="max-w-5xl mx-auto px-6 py-12">
  <h2 class="text-3xl font-bold text-center mb-8">Event Survival Kit</h2>
  <div class="grid sm:grid-cols-3 gap-6 mb-12">
    <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200 bounce">
      <span class="text-3xl">🎧</span>
      <h3 class="text-xl font-semibold mt-2 mb-1">Bassiani Entry</h3>
      <p class="text-gray-300">Bouncers tough? Get door hacks in #Nightlife on Telegram.</p>
    </div>
    <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200 bounce">
      <span class="text-3xl">🚇</span>
      <h3 class="text-xl font-semibold mt-2 mb-1">Nighttime Metro</h3>
      <p class="text-gray-300">Navigate Tbilisi’s metro after dark. Tips in #NomadLife.</p>
    </div>
    <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200 bounce">
      <span class="text-3xl">🚗</span>
      <h3 class="text-xl font-semibold mt-2 mb-1">Cheap Bolts</h3>
      <p class="text-gray-300">Score affordable rides to Lolita. Hacks in #NomadLife.</p>
    </div>
  </div>
</section>

<!-- ===== Event Filters & Listings ===== -->
<section class="max-w-5xl mx-auto px-6 py-12" x-data="{
  events: <?php echo json_encode($events); ?>,
  types: ['All', 'Nightlife', 'Foodie', 'Tech', 'Culture', 'Networking', 'Other'],
  locations: ['All', 'Old Tbilisi', 'Vake', 'Saburtalo', 'Fabrika', 'Rustaveli', 'Other']
}">
  <h2 class="text-3xl font-bold mb-8">All Upcoming Events 🔥</h2>
  <!-- Filters -->
  <div class="grid sm:grid-cols-3 gap-4 mb-8">
    <input type="text" x-model="search" placeholder="Search events (e.g., Khachapuri, Fabrika)..."
           class="p-3 rounded-lg text-black placeholder-gray-500 focus:ring-2 focus:ring-amber-400" />
    <select x-model="type" class="p-3 rounded-lg text-black">
      <template x-for="t in types" :key="t">
        <option x-text="t" :value="t"></option>
      </template>
    </select>
    <select x-model="location" class="p-3 rounded-lg text-black">
      <template x-for="l in locations" :key="l">
        <option x-text="l" :value="l"></option>
      </template>
    </select>
  </div>
  <!-- Listings -->
  <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
    <template x-for="event in events.filter(e => 
      (search === '' || e.title.toLowerCase().includes(search.toLowerCase()) || e.description.toLowerCase().includes(search.toLowerCase())) &&
      (type === 'All' || e.type === type) &&
      (location === 'All' || e.location === location)
    ).sort((a, b) => new Date(a.event_date) - new Date(b.event_date))" :key="event.id">
      <div class="bg-gray-800 rounded-xl overflow-hidden hover:bg-gray-750 transition duration-200">
        <img :src="event.image || 'https://picsum.photos/seed/event' + event.id + '/400/200'" :alt="event.title" class="w-full h-40 object-cover">
        <div class="p-6">
          <h3 class="text-xl font-semibold mb-2" x-text="event.title"></h3>
          <p class="text-sm text-gray-400 mb-2">
            📅 <span x-text="new Date(event.event_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })"></span> •
            📍 <span x-text="event.location"></span>
          </p>
          <p class="text-gray-200 mb-4" x-text="event.description"></p>
          <div class="flex gap-2 mb-4">
            <span class="bg-amber-500 text-gray-900 text-xs font-semibold px-2 py-1 rounded" x-show="event.is_nomad_pick">Nomad Pick</span>
            <span class="bg-gray-700 text-gray-300 text-xs font-semibold px-2 py-1 rounded" x-text="event.type || 'Meetup'"></span>
          </div>
          <div class="flex gap-4">
            <a :href="'https://t.me/+TbilisiNomads?event=' + event.id" target="_blank" class="bg-amber-500 hover:bg-amber-400 px-4 py-2 rounded-lg font-bold text-gray-900 pulse">RSVP on Telegram</a>
            <a :href="'https://t.me/+TbilisiNomads?event=' + event.id" target="_blank" class="text-amber-400 hover:text-amber-300 underline">Chat #Events</a>
          </div>
        </div>
      </div>
    </template>
    <p x-show="events.filter(e => 
      (search === '' || e.title.toLowerCase().includes(search.toLowerCase()) || e.description.toLowerCase().includes(search.toLowerCase())) &&
      (type === 'All' || e.type === type) &&
      (location === 'All' || e.location === location)
    ).length === 0" class="text-gray-400 text-center col-span-3">
      No events match your filters. Join Telegram for the latest!
    </p>
  </div>
</section>

<!-- ===== Telegram Teaser ===== -->
<section class="bg-gray-850 py-16">
  <div class="max-w-5xl mx-auto px-6 text-center">
    <h2 class="text-4xl font-bold mb-6">Unlock Tbilisi’s Wildest Events 🔥</h2>
    <p class="text-xl text-gray-200 mb-8">
      Secret sulfur bath pop-ups, khinkali-eating contests, Fabrika raves—join <span class="font-semibold">Telegram #Events</span> for exclusive invites and real-time vibes. Locals & nomads unite! <span class="text-amber-400">Gagimarjos!</span>
    </p>
    <div class="grid sm:grid-cols-3 gap-6 mb-10">
      <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200 bounce">
        <span class="text-3xl">🎉</span>
        <h3 class="text-xl font-semibold mt-2">Secret Pop-Ups</h3>
        <p class="text-gray-300">Get invites to hidden Tbilisi parties in #Events.</p>
      </div>
      <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200 bounce">
        <span class="text-3xl">🍷</span>
        <h3 class="text-xl font-semibold mt-2">Wine Nights</h3>
        <p class="text-gray-300">Toast at Lolita with nomads in #Nightlife.</p>
      </div>
      <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200 bounce">
        <span class="text-3xl">🥟</span>
        <h3 class="text-xl font-semibold mt-2">Foodie Feasts</h3>
        <p class="text-gray-300">Khachapuri crawls and babushka dinners in #Foodies.</p>
      </div>
    </div>
    <a href="https://t.me/+TbilisiNomads" target="_blank" class="bg-amber-500 hover:bg-amber-400 px-10 py-5 rounded-lg font-bold text-gray-900 pulse text-lg">
      Join Telegram for Exclusive Invites →
    </a>
  </div>
</section>

<!-- ===== Footer ===== -->
<footer class="bg-gray-800 text-gray-400 text-sm py-10">
  <div class="max-w-5xl mx-auto px-6">
    <div class="grid sm:grid-cols-3 gap-6 mb-6">
      <div>
        <h4 class="text-white font-semibold mb-2">Tbilisi Nomads</h4>
        <p>Inspired by Nomad List, built for Georgia’s wild heart. Locals & nomads unite!</p>
      </div>
      <div>
        <h4 class="text-white font-semibold mb-2">Quick Links</h4>
        <ul class="space-y-1">
          <li><a href="/index.php" class="hover:text-amber-400">Home</a></li>
          <li><a href="/hoods.php" class="hover:text-amber-400">Neighborhoods</a></li>
          <li><a href="/community.php" class="hover:text-amber-400">Community</a></li>
          <li><a href="/jobs.php" class="hover:text-amber-400">Jobs</a></li>
        </ul>
      </div>
      <div>
        <h4 class="text-white font-semibold mb-2">Stay Updated</h4>
        <form class="flex gap-2">
          <input type="email" placeholder="Your email…" class="flex-1 p-2 rounded text-black">
          <button class="bg-amber-500 hover:bg-amber-400 px-4 py-2 rounded text-gray-900">Subscribe</button>
        </form>
      </div>
    </div>
    <p class="text-center">© <?= date('Y') ?> Tbilisi Nomads. Crafted with ❤️ for remote workers.</p>
  </div>
</footer>

</body>
</html>