<?php
require_once __DIR__ . '/../config.php';
$pdo  = db();
$jobs = $pdo->query('SELECT * FROM jobs ORDER BY id DESC')
            ->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Remote Jobs & Collabs – Tbilisi Nomads</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
  <style>
    @keyframes pulse {
      0% { transform: scale(1); }
      50% { transform: scale(1.05); }
      100% { transform: scale(1); }
    }
    .pulse:hover {
      animation: pulse 0.3s ease-in-out;
    }
    @keyframes bounce {
      0%, 100% { transform: translateY(0); }
      50% { transform: translateY(-5px); }
    }
    .bounce:hover {
      animation: bounce 0.4s ease-in-out;
    }
    .parallax {
      background-attachment: fixed;
      background-position: center;
      background-repeat: no-repeat;
      background-size: cover;
    }
  </style>
</head>
<body class="bg-gray-900 text-white font-sans" x-data="{ search: '', role: '', seniority: '', salary: '' }">

<?php include __DIR__.'/partials/header.php'; ?>  <!-- nav bar -->

<!-- ===== Hero CTA ===== -->
<section class="parallax bg-[url('https://images.unsplash.com/photo-1611679700937-3b99c208a32f')] bg-cover bg-center">
  <div class="backdrop-brightness-50 py-20">
    <div class="max-w-4xl mx-auto text-center px-6">
      <h1 class="text-5xl sm:text-6xl font-extrabold mb-6 tracking-tight">
        Remote Jobs <span class="text-amber-400">🔥 Keep Roaming</span>
      </h1>
      <p class="text-xl sm:text-2xl text-gray-200 mb-10 leading-relaxed">
        Tbilisi’s job scene tapped out? Join <span class="font-bold text-white">37,756+</span> nomads on Telegram to score remote gigs, collab with Tbilisi lovers, and stay out of your parents’ basement. <span class="text-amber-400">Gagimarjos!</span>
      </p>
      <a href="https://t.me/+TbilisiNomads" target="_blank" class="bg-amber-500 hover:bg-amber-400 px-10 py-5 rounded-lg font-bold text-gray-900 pulse text-lg">
        Join Telegram for Job Leads →
      </a>
    </div>
  </div>
</section>

<!-- ===== Nomad Fixes ===== -->
<section class="max-w-5xl mx-auto px-6 py-12">
  <h2 class="text-3xl font-bold text-center mb-8">Job Hunt Hacks for Nomads</h2>
  <div class="grid sm:grid-cols-3 gap-6 mb-12">
    <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200 bounce">
      <span class="text-3xl">💻</span>
      <h3 class="text-xl font-semibold mt-2 mb-1">Upwork Hacks</h3>
      <p class="text-gray-300">Craft killer proposals. Get tips in #JobLeads on Telegram.</p>
    </div>
    <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200 bounce">
      <span class="text-3xl">🚫</span>
      <h3 class="text-xl font-semibold mt-2 mb-1">Avoid Scams</h3>
      <p class="text-gray-300">Spot shady gigs. Ask #SideHustles for red flags.</p>
    </div>
    <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200 bounce">
      <span class="text-3xl">🤝</span>
      <h3 class="text-xl font-semibold mt-2 mb-1">Collab in Tbilisi</h3>
      <p class="text-gray-300">Find nomads for startups at Fabrika. Join #Collabs.</p>
    </div>
  </div>
</section>

<!-- ===== Job Filters & Listings ===== -->
<section class="max-w-5xl mx-auto px-6 py-12" x-data="{
  jobs: <?php echo json_encode($jobs); ?>,
  roles: ['All', 'Tech', 'Design', 'Marketing', 'Writing', 'Freelance', 'Other'],
  seniorities: ['All', 'Entry', 'Mid', 'Senior'],
  salaries: ['All', '$30k+', '$60k+', '$100k+']
}">
  <h2 class="text-3xl font-bold mb-8">Find Your Next Remote Gig 🔥</h2>
  <!-- Filters -->
  <div class="grid sm:grid-cols-4 gap-4 mb-8">
    <input type="text" x-model="search" placeholder="Search jobs (e.g., Developer, Freelance)..."
           class="p-3 rounded-lg text-black placeholder-gray-500 focus:ring-2 focus:ring-amber-400" />
    <select x-model="role" class="p-3 rounded-lg text-black">
      <template x-for="r in roles" :key="r">
        <option x-text="r" :value="r"></option>
      </template>
    </select>
    <select x-model="seniority" class="p-3 rounded-lg text-black">
      <template x-for="s in seniorities" :key="s">
        <option x-text="s" :value="s"></option>
      </template>
    </select>
    <select x-model="salary" class="p-3 rounded-lg text-black">
      <template x-for="s in salaries" :key="s">
        <option x-text="s" :value="s"></option>
      </template>
    </select>
  </div>
  <!-- Listings -->
  <div class="space-y-6">
    <template x-for="job in jobs.filter(j => 
      (search === '' || j.title.toLowerCase().includes(search.toLowerCase()) || j.company.toLowerCase().includes(search.toLowerCase())) &&
      (role === 'All' || j.role === role) &&
      (seniority === 'All' || j.seniority === seniority) &&
      (salary === 'All' || (salary === '$30k+' && j.salary >= 30000) || (salary === '$60k+' && j.salary >= 60000) || (salary === '$100k+' && j.salary >= 100000))
    )" :key="job.id">
      <a :href="job.link" target="_blank" class="block bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200">
        <div class="flex justify-between items-start">
          <div>
            <h2 class="text-xl font-semibold" x-text="job.title"></h2>
            <p class="text-gray-400" x-text="job.company"></p>
            <p class="text-sm text-gray-400 mt-1">
              <span x-text="job.role || 'Freelance'"></span> • 
              <span x-text="job.seniority || 'Mid'"></span> • 
              <span x-text="job.salary ? `$${job.salary/1000}k` : '$60k+'"></span>
            </p>
            <div class="flex gap-2 mt-2">
              <span class="bg-amber-500 text-gray-900 text-xs font-semibold px-2 py-1 rounded" x-show="job.is_collab">Collab Opportunity</span>
              <span class="bg-gray-700 text-gray-300 text-xs font-semibold px-2 py-1 rounded" x-text="job.role || 'Remote'"></span>
            </div>
          </div>
          <button class="bg-amber-500 hover:bg-amber-400 px-4 py-2 rounded-lg font-bold text-gray-900 pulse">Apply Now</button>
        </div>
      </a>
    </template>
    <p x-show="jobs.filter(j => 
      (search === '' || j.title.toLowerCase().includes(search.toLowerCase()) || j.company.toLowerCase().includes(search.toLowerCase())) &&
      (role === 'All' || j.role === role) &&
      (seniority === 'All' || j.seniority === seniority) &&
      (salary === 'All' || (salary === '$30k+' && j.salary >= 30000) || (salary === '$60k+' && j.salary >= 60000) || (salary === '$100k+' && j.salary >= 100000))
    ).length === 0" class="text-gray-400 text-center">
      No jobs match your filters. Join Telegram for fresh leads!
    </p>
  </div>
</section>

<!-- ===== Collaboration Hub ===== -->
<section class="bg-gray-850 py-16">
  <div class="max-w-5xl mx-auto px-6 text-center">
    <h2 class="text-4xl font-bold mb-6">Collab with Tbilisi Lovers 🔥</h2>
    <p class="text-xl text-gray-200 mb-8">
      Fallen for Tbilisi’s chaos? Team up with nomads and locals for side hustles, startups, or khachapuri-fueled brainstorms. From Fabrika to Rustaveli, build your next big thing. Join <span class="font-semibold">Telegram #Collabs</span> to start!
    </p>
    <div class="grid sm:grid-cols-3 gap-6 mb-10">
      <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200 bounce">
        <span class="text-3xl">🚀</span>
        <h3 class="text-xl font-semibold mt-2">Startups</h3>
        <p class="text-gray-300">Pitch ideas with nomads in #Collabs.</p>
      </div>
      <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200 bounce">
        <span class="text-3xl">💸</span>
        <h3 class="text-xl font-semibold mt-2">Freelance Gigs</h3>
        <p class="text-gray-300">Find clients in #SideHustles.</p>
      </div>
      <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200 bounce">
        <span class="text-3xl">🤝</span>
        <h3 class="text-xl font-semibold mt-2">Local Partners</h3>
        <p class="text-gray-300">Team up with Tbilisi locals in #JobLeads.</p>
      </div>
    </div>
    <a href="https://t.me/+TbilisiNomads" target="_blank" class="bg-amber-500 hover:bg-amber-400 px-10 py-5 rounded-lg font-bold text-gray-900 pulse text-lg">
      Join Telegram to Collab →
    </a>
  </div>
</section>

<!-- ===== Fuck It, Let’s Start a Business Here ===== -->
<section class="max-w-5xl mx-auto px-6 py-16">
  <h2 class="text-4xl font-bold text-center mb-8">Fuck It, Let’s Start a Business Here 🔥</h2>
  <p class="text-xl text-gray-200 text-center mb-10">
    Why chase jobs? Georgia’s entrepreneur paradise—1% tax, $100 registration—lets you build your empire in Tbilisi’s chaos. From Stamba brainstorms to Fabrika pitches, here’s how to roll. <span class="text-amber-400">Gagimarjos!</span>
  </p>
  <div class="grid sm:grid-cols-3 gap-6 mb-12">
    <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200 bounce">
      <span class="text-3xl">💸</span>
      <h3 class="text-xl font-semibold mt-2 mb-1">Low Taxes, No Bullshit</h3>
      <p class="text-gray-300">Micro-business? 1% tax up to $15k revenue. Register for $100 in a day. Ask #StartupTbilisi for accountants.</p>
    </div>
    <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200 bounce">
      <span class="text-3xl">🏢</span>
      <h3 class="text-xl font-semibold mt-2 mb-1">Tbilisi Hacks</h3>
      <p class="text-gray-300">Cowork at Impact Hub, pitch at Startup Grind. Source coders via #Collabs. Khachapuri fuels the grind.</p>
    </div>
    <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200 bounce">
      <span class="text-3xl">⚠️</span>
      <h3 class="text-xl font-semibold mt-2 mb-1">Watch Out</h3>
      <p class="text-gray-300">Language barriers? Shady “consultants”? Get vetted lawyers in #StartupTbilisi. Don’t sign blind.</p>
    </div>
  </div>
  <div class="text-center">
    <a href="https://t.me/+TbilisiNomads" target="_blank" class="bg-amber-500 hover:bg-amber-400 px-10 py-5 rounded-lg font-bold text-gray-900 pulse text-lg">
      Join #StartupTbilisi for Mentors & Investors →
    </a>
  </div>
</section>

<!-- ===== Footer ===== -->
<footer class="bg-gray-800 text-gray-400 text-sm py-10">
  <div class="max-w-5xl mx-auto px-6">
    <div class="grid sm:grid-cols-3 gap-6 mb-6">
      <div>
        <h4 class="text-white font-semibold mb-2">Tbilisi Nomads</h4>
        <p>Inspired by Nomad List, built for Georgia’s wild heart. Stay on the road!</p>
      </div>
      <div>
        <h4 class="text-white font-semibold mb-2">Quick Links</h4>
        <ul class="space-y-1">
          <li><a href="/index.php" class="hover:text-amber-400">Home</a></li>
          <li><a href="/hoods.php" class="hover:text-amber-400">Neighborhoods</a></li>
          <li><a href="/community.php" class="hover:text-amber-400">Community</a></li>
        </ul>
      </div>
      <div>
        <h4 class="text-white font-semibold mb-2">Stay Updated</h4>
        <form class="flex gap-2">
          <input type="email" placeholder="Your email…" class="flex-1 p-2 rounded text-black">
          <button class="bg-amber-500 hover:bg-amber-400 px-4 py-2 rounded text-gray-900">Subscribe</button>
        </form>
      </div>
    </div>
    <p class="text-center">© <?= date('Y') ?> Tbilisi Nomads. Crafted with ❤️ for remote workers.</p>
  </div>
</footer>

</body>
</html>