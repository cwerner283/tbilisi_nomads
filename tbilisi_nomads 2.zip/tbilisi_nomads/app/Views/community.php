<?php
require_once __DIR__ . '/../config.php';
$pdo = db();

/* ---------- handle new post ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? 'Anonymous');
    $msg  = trim($_POST['message'] ?? '');

    if ($msg !== '') {
        $stmt = $pdo->prepare('INSERT INTO notes (name, message) VALUES (?, ?)');
        $stmt->execute([$name, $msg]);
    }
    // Redirect to avoid form re-submit on refresh
    header('Location: community.php');
    exit;
}

/* ---------- fetch notes ---------- */
$notes = $pdo->query('SELECT * FROM notes ORDER BY created_at DESC')
             ->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Community Hub – Tbilisi Nomads</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
  <style>
    @keyframes pulse {
      0% { transform: scale(1); }
      50% { transform: scale(1.05); }
      100% { transform: scale(1); }
    }
    .pulse:hover {
      animation: pulse 0.3s ease-in-out;
    }
    .parallax {
      background-attachment: fixed;
      background-position: center;
      background-repeat: no-repeat;
      background-size: cover;
    }
    @keyframes bounce {
      0%, 100% { transform: translateY(0); }
      50% { transform: translateY(-5px); }
    }
    .bounce:hover {
      animation: bounce 0.4s ease-in-out;
    }
  </style>
</head>
<body class="bg-gray-900 text-white font-sans" x-data="{ message: '', maxChars: 280 }">

<?php include __DIR__.'/partials/header.php'; ?>  <!-- nav bar -->

<!-- ===== Hero CTA ===== -->
<section class="parallax bg-[url('https://images.unsplash.com/photo-1611679700937-3b99c208a32f')] bg-cover bg-center">
  <div class="backdrop-brightness-50 py-20">
    <div class="max-w-4xl mx-auto text-center px-6">
      <h1 class="text-5xl sm:text-6xl font-extrabold mb-6 tracking-tight">
        Tbilisi Nomads <span class="text-amber-400">🔥 Gagimarjos!</span>
      </h1>
      <p class="text-xl sm:text-2xl text-gray-200 mb-10 leading-relaxed">
        Bounced at Bassiani? Wanna join Rustaveli’s fire? Need a babushka’s khachapuri feast? Unite with <span class="font-bold text-white">37,756+</span> locals & nomads on Telegram for fixes, vibes, and family-style feasts.
      </p>
      <a href="https://t.me/+TbilisiNomads" target="_blank" class="bg-amber-500 hover:bg-amber-400 px-10 py-5 rounded-lg font-bold text-gray-900 pulse text-lg">
        Join Telegram Tribe →
      </a>
    </div>
  </div>
</section>

<!-- ===== Nomad Fixes ===== -->
<section class="max-w-5xl mx-auto px-6 py-12">
  <h2 class="text-3xl font-bold text-center mb-8">Tbilisi Survival Kit: Locals & Nomads Unite</h2>
  <div class="grid sm:grid-cols-3 gap-6 mb-12">
    <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200 bounce">
      <span class="text-3xl">📱</span>
      <h3 class="text-xl font-semibold mt-2 mb-1">Magti/Silknet Fixes</h3>
      <p class="text-gray-300">SIM dead? Get eSIM hacks or top-up spots in #TechHelp on Telegram.</p>
    </div>
    <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200 bounce">
      <span class="text-3xl">🥟</span>
      <h3 class="text-xl font-semibold mt-2 mb-1">Khachapuri Crews</h3>
      <p class="text-gray-300">Find the cheesiest spots in Vake. Join #Foodies for crawls.</p>
    </div>
    <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200 bounce">
      <span class="text-3xl">💻</span>
      <h3 class="text-xl font-semibold mt-2 mb-1">Coworking Hubs</h3>
      <p class="text-gray-300">Fast WiFi at Fabrika? Get recs in #WorkHardPlayHard.</p>
    </div>
    <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200 bounce">
      <span class="text-3xl">🎧</span>
      <h3 class="text-xl font-semibold mt-2 mb-1">Bassiani Door Hacks</h3>
      <p class="text-gray-300">Bouncers reject you? Learn the vibe in #Nightlife on Telegram.</p>
    </div>
    <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200 bounce">
      <span class="text-3xl">✊</span>
      <h3 class="text-xl font-semibold mt-2 mb-1">Rustaveli Protests</h3>
      <p class="text-gray-300">Why’s the street burning? Join #LocalVibes for safe intel.</p>
    </div>
    <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200 bounce">
      <span class="text-3xl">🍽️</span>
      <h3 class="text-xl font-semibold mt-2 mb-1">Babushka’s Table</h3>
      <p class="text-gray-300">Eat like family with locals. Find dinners in #Foodies.</p>
    </div>
  </div>
</section>

<!-- ===== Post Form ===== -->
<section class="max-w-3xl mx-auto px-6 py-12">
  <h2 class="text-3xl font-bold mb-6">Drop a Note, Kargi Gogo 🔥</h2>
  <form method="post" class="mb-12 grid gap-4" x-data="{ name: '' }">
    <div class="flex items-center gap-4">
      <img src="https://i.pravatar.cc/48?u=<?= rand(1, 70) ?>" alt="User avatar" class="rounded-full w-12 h-12">
      <input name="name" x-model="name" placeholder="Your name (or go Anonymous)"
             class="flex-1 p-3 rounded-lg text-black placeholder-gray-500 focus:ring-2 focus:ring-amber-400" />
    </div>
    <div class="relative">
      <textarea name="message" x-model="message" placeholder="Got Bassiani tips? Rustaveli protest intel? Babushka dinner recs? Spill the tea!"
                class="w-full p-3 rounded-lg text-black placeholder-gray-500 focus:ring-2 focus:ring-amber-400"
                rows="4" maxlength="280"></textarea>
      <p class="absolute bottom-2 right-3 text-sm text-gray-400"
         x-text="`${message.length}/${maxChars}`"></p>
    </div>
    <button class="bg-amber-500 hover:bg-amber-400 px-6 py-3 rounded-lg font-bold text-gray-900 pulse"
            :disabled="message.trim().length === 0">
      Post to the Tribe
    </button>
  </form>

  <!-- ===== Notes Feed ===== -->
  <div class="space-y-6">
    <?php foreach ($notes as $n): ?>
      <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200">
        <div class="flex items-start gap-4">
          <img src="https://i.pravatar.cc/48?u=<?= crc32($n['name']) ?>" alt="User avatar" class="rounded-full w-12 h-12">
          <div class="flex-1">
            <div class="flex justify-between items-center mb-2">
              <div class="text-sm font-semibold">
                <?= htmlspecialchars($n['name']) ?>
                <span class="text-gray-400 font-normal">• <?= date('M j, Y', strtotime($n['created_at'])) ?></span>
              </div>
              <div class="flex gap-2">
                <button class="text-gray-400 hover:text-amber-400">❤️ 0</button>
                <button class="text-gray-400 hover:text-amber-400">💬 Reply</button>
              </div>
            </div>
            <p class="text-gray-200"><?= nl2br(htmlspecialchars($n['message'])) ?></p>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- ===== Telegram Teaser ===== -->
<section class="bg-gray-850 py-16">
  <div class="max-w-4xl mx-auto px-6 text-center">
    <h2 class="text-4xl font-bold mb-6">Join the Telegram Tribe 🔥</h2>
    <p class="text-xl text-gray-200 mb-8">
      Unlock <span class="font-semibold">Tbilisi Nomads Telegram</span> for 24/7 chats with locals & nomads. Get Bassiani door hacks, Rustaveli protest vibes, babushka dinners, and more. <span class="text-amber-400">Tbilisi’s heart beats for all!</span>
    </p>
    <div class="grid sm:grid-cols-3 gap-6 mb-10">
      <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200 bounce">
        <span class="text-3xl">🎧</span>
        <h3 class="text-xl font-semibold mt-2">Nightlife Hacks</h3>
        <p class="text-gray-300">Crack Bassiani’s door code in #Nightlife.</p>
      </div>
      <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200 bounce">
        <span class="text-3xl">✊</span>
        <h3 class="text-xl font-semibold mt-2">Local Vibes</h3>
        <p class="text-gray-300">Rustaveli protests? Get the scoop in #LocalVibes.</p>
      </div>
      <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200 bounce">
        <span class="text-3xl">🍽️</span>
        <h3 class="text-xl font-semibold mt-2">Babushka Feasts</h3>
        <p class="text-gray-300">Home-cooked meals with #Foodies.</p>
      </div>
      <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200 bounce">
        <span class="text-3xl">📲</span>
        <h3 class="text-xl font-semibold mt-2">Tech Fixes</h3>
        <p class="text-gray-300">Magti or Silknet down? #TechHelp has you.</p>
      </div>
      <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200 bounce">
        <span class="text-3xl">🍷</span>
        <h3 class="text-xl font-semibold mt-2">Wine & Dine</h3>
        <p class="text-gray-300">Lolita meetups via #Events.</p>
      </div>
      <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200 bounce">
        <span class="text-3xl">🛂</span>
        <h3 class="text-xl font-semibold mt-2">Visa & SIM</h3>
        <p class="text-gray-300">Navigate Tbilisi life in #NomadLife.</p>
      </div>
    </div>
    <a href="https://t.me/+TbilisiNomads" target="_blank" class="bg-amber-500 hover:bg-amber-400 px-10 py-5 rounded-lg font-bold text-gray-900 pulse text-lg">
      Join Telegram to Unlock →
    </a>
  </div>
</section>

<!-- ===== Footer ===== -->
<footer class="bg-gray-800 text-gray-400 text-sm py-10">
  <div class="max-w-5xl mx-auto px-6">
    <div class="grid sm:grid-cols-3 gap-6 mb-6">
      <div>
        <h4 class="text-white font-semibold mb-2">Tbilisi Nomads</h4>
        <p>Inspired by Nomad List, built for Georgia’s wild heart. Locals & nomads unite!</p>
      </div>
      <div>
        <h4 class="text-white font-semibold mb-2">Quick Links</h4>
        <ul class="space-y-1">
          <li><a href="/index.php" class="hover:text-amber-400">Home</a></li>
          <li><a href="/hoods.php" class="hover:text-amber-400">Neighborhoods</a></li>
          <li><a href="/meetups.php" class="hover:text-amber-400">Meetups</a></li>
        </ul>
      </div>
      <div>
        <h4 class="text-white font-semibold mb-2">Stay Updated</h4>
        <form class="flex gap-2">
          <input type="email" placeholder="Your email…" class="flex-1 p-2 rounded text-black">
          <button class="bg-amber-500 hover:bg-amber-400 px-4 py-2 rounded text-gray-900">Subscribe</button>
        </form>
      </div>
    </div>
    <p class="text-center">© <?= date('Y') ?> Tbilisi Nomads. Crafted with ❤️ for remote workers.</p>
  </div>
</footer>

</body>
</html>