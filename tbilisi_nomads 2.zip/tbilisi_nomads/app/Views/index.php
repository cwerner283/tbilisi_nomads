<?php ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Tbilisi Nomads – Your Home for Remote Work in Georgia</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
  <style>
    .parallax {
      background-attachment: fixed;
      background-position: center;
      background-repeat: no-repeat;
      background-size: cover;
    }
    @keyframes pulse {
      0% { transform: scale(1); }
      50% { transform: scale(1.05); }
      100% { transform: scale(1); }
    }
    .pulse:hover {
      animation: pulse 0.3s ease-in-out;
    }
  </style>
</head>
<body class="bg-gray-900 text-white font-sans" x-data="{ search: '', sort: '' }">

<?php include __DIR__.'/partials/header.php'; ?>  <!-- nav bar -->

<!-- ===== Hero / headline ===== -->
<section class="parallax bg-[url('https://i.postimg.cc/LX4MbbV1/IMG-0048.jpg')] bg-cover bg-center">
  <div class="backdrop-brightness-50 py-24">
    <div class="max-w-4xl mx-auto text-center px-6">
      <h1 class="text-5xl sm:text-6xl font-extrabold mb-6 tracking-tight">
        Tbilisi Nomads: <span class="text-amber-400">Your Tribe Awaits</span>
      </h1>
      <p class="text-xl sm:text-2xl text-gray-200 mb-10 leading-relaxed">
        Connect with <span class="font-bold text-white" x-text="Math.floor(37756 + (Date.now() - new Date('2025-07-07').getTime()) / (1000 * 60 * 60 * 24))">37,756</span> nomads thriving in Tbilisi’s vibrant streets. From Vake’s cafés to Old Town’s charm, find your spot, meet your people, and live the dream.
      </p>
      <!-- CTA -->
      <form class="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
        <input type="email" name="email" required
               placeholder="Your email to join…"
               class="flex-1 p-4 rounded-lg text-black placeholder-gray-500 focus:ring-2 focus:ring-amber-400" />
        <button class="bg-amber-500 hover:bg-amber-400 px-8 py-4 rounded-lg font-bold text-gray-900 pulse">
          Join the Tribe →
        </button>
      </form>
      <p class="mt-3 text-sm text-gray-300">
        Already a nomad? We’ll log you in.
      </p>
    </div>
  </div>
</section>

<!-- ===== Member avatars ===== -->
<section class="py-10 overflow-x-auto whitespace-nowrap bg-gray-800">
  <div class="flex justify-center gap-4 px-4">
    <?php for ($i = 1; $i <= 12; $i++): ?>
      <img src="https://i.pravatar.cc/80?img=<?= $i ?>" alt="Nomad member"
           class="inline-block rounded-full ring-2 ring-amber-400 hover:ring-amber-300 transition duration-200">
    <?php endfor; ?>
  </div>
</section>

<!-- ===== Perks ===== -->
<section class="max-w-5xl mx-auto px-6 py-16">
  <h2 class="text-4xl font-bold text-center mb-12">Why Tbilisi Nomads?</h2>
  <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
    <?php
    $perks = [
      ['icon'=>'🍹', 'title'=>'Weekly Meetups', 'desc'=>'Join 400+ events yearly at Tbilisi’s coolest cafés, bars, and coworking spaces.'],
      ['icon'=>'❤️', 'title'=>'Build Connections', 'desc'=>'Meet nomads for friendships, collabs, or even a khachapuri date.'],
      ['icon'=>'🧪', 'title'=>'Neighborhood Intel', 'desc'=>'Compare Vake, Saburtalo, and more to find your perfect work spot.'],
      ['icon'=>'🌎', 'title'=>'Track Your Journey', 'desc'=>'Log your Tbilisi adventures and share tips with the community.'],
      ['icon'=>'💬', 'title'=>'24/7 Chat', 'desc'=>'Stay connected with nomads via our lively community chats.'],
      ['icon'=>'☕', 'title'=>'Local Hacks', 'desc'=>'Get insider tips on Bolt rides, Magti plans, and the best khinkali joints.'],
    ];
    foreach ($perks as $p):
    ?>
      <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-700 transition duration-200 pulse">
        <span class="text-3xl"><?= $p['icon'] ?></span>
        <h3 class="text-xl font-semibold mt-2 mb-1"><?= $p['title'] ?></h3>
        <p class="text-gray-300"><?= $p['desc'] ?></p>
      </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- ===== Social proof ===== -->
<section class="bg-gray-850 py-16">
  <div class="max-w-5xl mx-auto px-6">
    <p class="text-center text-sm uppercase tracking-widest text-gray-400 mb-8">
      As Seen On
    </p>
    <div class="flex flex-wrap justify-center gap-8 grayscale opacity-70 hover:opacity-100 transition duration-300">
      <?php $brands = ['nyt','ft','bbc','cnn','usatoday','cnbc','guardian','politico']; ?>
      <?php foreach ($brands as $b): ?>
        <img src="https://dummyimage.com/120x32/ffffff/555555&text=<?= strtoupper($b) ?>"
             alt="<?= $b ?>" class="h-8 hover:grayscale-0 transition duration-200">
      <?php endforeach; ?>
    </div>
    <div class="mt-12" x-data="{ quotes: [
      { text: '“Tbilisi Nomads is the go-to for remote workers craving community and local insights.”', source: 'The Guardian' },
      { text: '“A game-changer for navigating Tbilisi’s neighborhoods with nomad-friendly data.”', source: 'CNN Travel' },
      { text: '“From meetups to vibe scores, this is how nomads do Tbilisi right.”', source: 'Nomad Magazine' }
    ], current: 0 }" x-init="setInterval(() => current = (current + 1) % quotes.length, 5000)">
      <blockquote class="text-center italic text-gray-200 text-lg"
                  x-text="quotes[current].text"></blockquote>
      <p class="text-center text-sm text-gray-400 mt-2" x-text="quotes[current].source"></p>
    </div>
  </div>
</section>

<!-- ===== Neighborhood Explorer ===== -->
<section class="max-w-6xl mx-auto px-6 py-16" x-data="{
  hoods: [
    { name: 'Vake', img: 'https://picsum.photos/seed/vakegrid/400/300', wifi: '80 Mbps', cost: '$$', walk: '7/10', vibe: 'Upscale, green, café-rich', tags: ['cafes', 'green', 'metro'] },
    { name: 'Saburtalo', img: 'https://picsum.photos/seed/saburtalogrid/400/300', wifi: '90 Mbps', cost: '$$', walk: '8/10', vibe: 'Lively, modern, hilly', tags: ['shops', 'metro', 'hilly'] },
    { name: 'Old Tbilisi', img: 'https://picsum.photos/seed/oldgrid/400/300', wifi: '70 Mbps', cost: '$$$', walk: '9/10', vibe: 'Historic, touristy, vibrant', tags: ['historic', 'cafes', 'walkable'] },
    { name: 'Mtatsminda', img: 'https://picsum.photos/seed/mtatsmindagrid/400/300', wifi: '75 Mbps', cost: '$$$', walk: '6/10', vibe: 'Quiet, scenic, upscale', tags: ['scenic', 'quiet', 'hilly'] }
  ]
}">
  <h2 class="text-4xl font-bold text-center mb-12">Discover Tbilisi’s Neighborhoods</h2>
  <!-- Search + sort -->
  <div class="flex flex-col sm:flex-row gap-4 mb-8">
    <input type="text" placeholder="Search (e.g. Vake, coffee, wifi)…" x-model="search"
           class="flex-1 p-4 rounded-lg text-black placeholder-gray-500 focus:ring-2 focus:ring-amber-400">
    <select x-model="sort" class="p-4 rounded-lg text-black">
      <option value="" selected>Sort by…</option>
      <option value="cost">Cost (low → high)</option>
      <option value="wifi">WiFi (fast → slow)</option>
      <option value="walk">Walkability</option>
    </select>
  </div>
  <!-- Grid -->
  <div class="grid md:grid-cols-3 lg:grid-cols-4 gap-6">
    <template x-for="hood in hoods.filter(h => h.name.toLowerCase().includes(search.toLowerCase()) || h.tags.some(t => t.includes(search.toLowerCase()))).sort((a, b) => {
      if (sort === 'cost') return a.cost.length - b.cost.length;
      if (sort === 'wifi') return parseInt(b.wifi) - parseInt(a.wifi);
      if (sort === 'walk') return parseInt(b.walk) - parseInt(a.walk);
      return 0;
    })" :key="hood.name">
      <div class="bg-gray-800 rounded-xl overflow-hidden shadow hover:shadow-lg transition duration-200">
        <img :src="hood.img" :alt="hood.name" class="h-48 w-full object-cover">
        <div class="p-5">
          <h3 class="text-xl font-semibold mb-2" x-text="hood.name"></h3>
          <p class="text-sm text-gray-400 mb-2" x-text="hood.vibe"></p>
          <p class="text-sm text-gray-400 mb-3">
            <span x-text="hood.wifi"></span> • <span x-text="hood.walk"></span> • <span x-text="hood.cost"></span>
          </p>
          <a href="/hoods.php" class="underline text-amber-400 hover:text-amber-300">View details →</a>
        </div>
      </div>
    </template>
  </div>
  <div class="text-center mt-12">
    <a href="/hoods.php" class="bg-amber-500 hover:bg-amber-400 px-8 py-4 rounded-lg font-bold text-gray-900 pulse">
      Explore All Neighborhoods
    </a>
  </div>
</section>

<!-- ===== Footer ===== -->
<footer class="bg-gray-800 text-gray-400 text-sm py-10">
  <div class="max-w-5xl mx-auto px-6">
    <div class="grid sm:grid-cols-3 gap-6 mb-6">
      <div>
        <h4 class="text-white font-semibold mb-2">Tbilisi Nomads</h4>
        <p>Inspired by Nomad List, built for Georgia’s vibrant capital. Join the tribe!</p>
      </div>
      <div>
        <h4 class="text-white font-semibold mb-2">Quick Links</h4>
        <ul class="space-y-1">
          <li><a href="/hoods.php" class="hover:text-amber-400">Neighborhoods</a></li>
          <li><a href="/meetups.php" class="hover:text-amber-400">Meetups</a></li>
          <li><a href="/chat.php" class="hover:text-amber-400">Community Chat</a></li>
        </ul>
      </div>
      <div>
        <h4 class="text-white font-semibold mb-2">Stay Updated</h4>
        <form class="flex gap-2">
          <input type="email" placeholder="Your email…" class="flex-1 p-2 rounded text-black">
          <button class="bg-amber-500 hover:bg-amber-400 px-4 py-2 rounded text-gray-900">Subscribe</button>
        </form>
      </div>
    </div>
    <p class="text-center">© <?= date('Y') ?> Tbilisi Nomads. Crafted with ❤️ for remote workers.</p>
  </div>
</footer>

</body>
</html>