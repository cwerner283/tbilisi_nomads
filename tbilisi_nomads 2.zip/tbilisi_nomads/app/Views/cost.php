<?php
require_once __DIR__ . '/../config.php';
$pdo = db();

$error_message = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $neighborhood = $_POST['neighborhood'] ?? 'Saburtalo';
        $fields = [
            'rent' => floatval($_POST['rent'] ?? 0),
            'magti' => floatval($_POST['magti'] ?? 0),
            'metro_rides' => intval($_POST['metro_rides'] ?? 0) * 0.50,
            'bolt_rides' => intval($_POST['bolt_rides'] ?? 0) * 3.00,
            'food' => floatval($_POST['food'] ?? 0) * intval($_POST['food_freq'] ?? 0)
        ];
        foreach ($fields as $item => $cost) {
            if ($cost > 0) {
                $stmt = $pdo->prepare("INSERT INTO costs (neighborhood, item, cost) VALUES (?, ?, ?)
                    ON CONFLICT(neighborhood, item) DO UPDATE SET cost=excluded.cost");
                $stmt->execute([$neighborhood, $item, $cost]);
            }
        }
        if (!empty($_POST['custom_item']) && floatval($_POST['custom_cost']) > 0) {
            $stmt = $pdo->prepare("INSERT INTO costs (neighborhood, item, cost) VALUES (?, ?, ?)
                ON CONFLICT(neighborhood, item) DO UPDATE SET cost=excluded.cost");
            $stmt->execute([$neighborhood, trim($_POST['custom_item']), floatval($_POST['custom_cost'])]);
        }
        header("Location: cost.php?neighborhood=" . urlencode($neighborhood));
        exit;
    } catch (PDOException $e) {
        $error_message = "Error saving costs: " . htmlspecialchars($e->getMessage());
    }
}

$neighborhood = $_GET['neighborhood'] ?? 'Saburtalo';
$neighborhoods = ['Vake', 'Saburtalo', 'Old Town', 'Mtatsminda'];
try {
    $costs = $pdo->query("SELECT * FROM costs WHERE neighborhood = ? ORDER BY item ASC")
        ->execute([$neighborhood])
        ->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error_message = "Error loading costs: " . htmlspecialchars($e->getMessage());
    $costs = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Cost Calculator – Tbilisi Nomads</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/styles.css">
</head>
<body class="text-white min-h-screen p-4 md:p-8 bg-gray-900">
  <?php include __DIR__ . '/partials/header.php'; ?>

  <div class="max-w-4xl mx-auto space-y-6">
    <h1 class="text-4xl font-bold mb-4 nomad-gradient bg-clip-text text-transparent">
      💸 Cost Calculator for <?php echo htmlspecialchars($neighborhood); ?>
    </h1>
    <p class="text-gray-300 text-lg max-w-xl">
      Build your monthly budget for <?php echo htmlspecialchars($neighborhood); ?>. Input rent, Magti, rides, and food to get real numbers for your nomad life.
    </p>

    <?php if ($error_message): ?>
      <div class="error-message"><?php echo $error_message; ?></div>
    <?php endif; ?>

    <!-- Cost Input Form -->
    <div class="card">
      <h2 class="text-xl font-semibold mb-4 text-rose-400">Your Monthly Costs</h2>
      <form method="POST" class="grid gap-4">
        <div>
          <label class="block text-sm font-medium mb-2 text-gray-300">Neighborhood</label>
          <select name="neighborhood" class="input-field" onchange="this.form.submit()">
            <?php foreach ($neighborhoods as $n): ?>
              <option value="<?php echo $n; ?>" <?php echo $n === $neighborhood ? 'selected' : ''; ?>>
                <?php echo $n; ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="grid gap-4 md:grid-cols-2">
          <div>
            <label class="block text-sm font-medium mb-2 text-gray-300">Rent (USD)</label>
            <input name="rent" type="number" step="0.01" placeholder="e.g., 600" class="input-field" value="<?php echo ($c = array_filter($costs, fn($c) => $c['item'] === 'rent')) ? reset($c)['cost'] : ''; ?>">
          </div>
          <div>
            <label class="block text-sm font-medium mb-2 text-gray-300">Magti Plan (USD)</label>
            <select name="magti" class="input-field">
              <option value="10" <?php echo ($c = array_filter($costs, fn($c) => $c['item'] === 'magti' && $c['cost'] == 10)) ? 'selected' : ''; ?>>Basic ($10)</option>
              <option value="15" <?php echo ($c = array_filter($costs, fn($c) => $c['item'] === 'magti' && $c['cost'] == 15)) ? 'selected' : ''; ?>>Standard ($15)</option>
              <option value="30" <?php echo ($c = array_filter($costs, fn($c) => $c['item'] === 'magti' && $c['cost'] == 30)) ? 'selected' : ''; ?>>Premium ($30)</option>
            </select>
          </div>
          <div>
            <label class="block text-sm font-medium mb-2 text-gray-300">Metro Rides (Monthly)</label>
            <input name="metro_rides" type="number" placeholder="e.g., 40" class="input-field" value="<?php echo ($c = array_filter($costs, fn($c) => $c['item'] === 'metro_rides')) ? round(reset($c)['cost'] / 0.50) : ''; ?>">
            <p class="text-sm text-gray-400 mt-1">$0.50 per ride</p>
          </div>
          <div>
            <label class="block text-sm font-medium mb-2 text-gray-300">Bolt Rides (Monthly)</label>
            <input name="bolt_rides" type="number" placeholder="e.g., 20" class="input-field" value="<?php echo ($c = array_filter($costs, fn($c) => $c['item'] === 'bolt_rides')) ? round(reset($c)['cost'] / 3.00) : ''; ?>">
            <p class="text-sm text-gray-400 mt-1">$3 per ride</p>
          </div>
          <div>
            <label class="block text-sm font-medium mb-2 text-gray-300">Food (Per Meal)</label>
            <select name="food" class="input-field">
              <option value="5" <?php echo ($c = array_filter($costs, fn($c) => $c['item'] === 'food' && $c['cost'] / 30 == 5)) ? 'selected' : ''; ?>>McDonald's ($5)</option>
              <option value="10" <?php echo ($c = array_filter($costs, fn($c) => $c['item'] === 'food' && $c['cost'] / 30 == 10)) ? 'selected' : ''; ?>>Mid-Range ($10)</option>
              <option value="20" <?php echo ($c = array_filter($costs, fn($c) => $c['item'] === 'food' && $c['cost'] / 30 == 20)) ? 'selected' : ''; ?>>High-End ($20)</option>
            </select>
          </div>
          <div>
            <label class="block text-sm font-medium mb-2 text-gray-300">Meals per Month</label>
            <input name="food_freq" type="number" placeholder="e.g., 30" class="input-field" value="30">
          </div>
          <div>
            <label class="block text-sm font-medium mb-2 text-gray-300">Lifestyle</label>
            <select id="lifestyle" class="input-field">
              <option value="0.8">Frugal</option>
              <option value="1" selected>Moderate</option>
              <option value="1.5">Comfortable</option>
              <option value="2">Luxury</option>
            </select>
          </div>
          <div>
            <label class="block text-sm font-medium mb-2 text-gray-300">Household Size</label>
            <input id="household" type="number" min="1" value="1" class="input-field">
          </div>
          <div>
            <label class="block text-sm font-medium mb-2 text-gray-300">Custom Item</label>
            <input name="custom_item" placeholder="e.g., Coworking" class="input-field">
          </div>
          <div>
            <label class="block text-sm font-medium mb-2 text-gray-300">Custom Cost (USD)</label>
            <input name="custom_cost" type="number" step="0.01" placeholder="e.g., 100" class="input-field">
          </div>
        </div>
        <button type="submit" class="btn bg-rose-600 hover:bg-rose-700 mt-4">Calculate</button>
      </form>
    </div>

    <!-- Cost Table -->
    <div class="card">
      <h2 class="text-xl font-semibold mb-4 text-indigo-400">Your Monthly Budget</h2>
      <div class="overflow-x-auto">
        <table class="w-full table-auto text-left">
          <thead class="bg-gray-700 text-gray-300">
            <tr>
              <th class="px-4 py-3 font-medium">Item</th>
              <th class="px-4 py-3 font-medium">Cost (USD)</th>
            </tr>
          </thead>
          <tbody id="costTable">
            <?php foreach ($costs as $row): ?>
              <tr class="border-t border-gray-700 hover:bg-gray-700 transition">
                <td class="px-4 py-3 <?php echo $row['item']; ?>">
                  <?php echo htmlspecialchars(ucwords(str_replace('_', ' ', $row['item']))); ?>
                </td>
                <td class="px-4 py-3 cost-val" data-base="<?php echo $row['cost']; ?>">
                  <?php echo number_format($row['cost'], 2); ?>
                </td>
              </tr>
            <?php endforeach; ?>
            <tr class="border-t border-gray-700 font-semibold">
              <td class="px-4 py-3">Total</td>
              <td class="px-4 py-3" id="total-cost">
                <?php echo number_format(array_sum(array_column($costs, 'cost')), 2); ?>
              </td>
            </tr>
        </table>
      </div>
    </div>
  </div>

  <script>
    function adjustEstimates() {
      const factor = parseFloat(document.getElementById("lifestyle").value);
      const people = parseInt(document.getElementById("household").value) || 1;
      let total = 0;
      document.querySelectorAll(".cost-val").forEach(td => {
        const base = parseFloat(td.dataset.base);
        const adjusted = base * factor * people;
        td.textContent = adjusted.toFixed(2);
        total += adjusted;
      });
      document.getElementById("total-cost").textContent = total.toFixed(2);
    }
    document.getElementById("lifestyle").addEventListener("change", adjustEstimates);
    document.getElementById("household").addEventListener("input", adjustEstimates);
    adjustEstimates();
  </script>
</body>
</html>