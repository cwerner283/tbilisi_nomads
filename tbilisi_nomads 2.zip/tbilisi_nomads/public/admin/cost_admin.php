<?php
require_once __DIR__.'/../../config.php';
session_start();

/* ---- crude auth (one hard-coded password) ---- */
const ADMIN_PASS = 'changeme123';
if (!isset($_SESSION['admin'])) {
  if ($_SERVER['REQUEST_METHOD']==='POST' && $_POST['p']===ADMIN_PASS)
    $_SESSION['admin']=true;
  else {
    echo '<form method="post" class="p-10 text-center">
            <input type="password" name="p" placeholder="Password"
                   class="p-2 rounded text-black">
            <button class="bg-blue-600 px-4 py-2 rounded text-white">Log in</button>
          </form>';
    exit;
  }
}

/* ---- CRUD ---- */
$pdo = db();
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['item'])) {
  $pdo->prepare('INSERT INTO costs(item,cost) VALUES(?,?)
                 ON CONFLICT(item) DO UPDATE SET cost = excluded.cost')
      ->execute([$_POST['item'], $_POST['cost']]);
  header('Location: cost_admin.php');
  exit;
}
$rows=$pdo->query('SELECT * FROM costs ORDER BY item')->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html><head>
<meta charset="UTF-8"><script src="https://cdn.tailwindcss.com"></script>
<title>Admin – Costs</title></head>
<body class="bg-gray-900 text-white p-6">
<h1 class="text-3xl font-bold mb-6">Admin: Static Cost Items</h1>
<table class="mb-6 w-full">
  <?php foreach($rows as $r): ?>
    <tr><td class="py-1"><?=htmlspecialchars($r['item'])?></td>
        <td><?=number_format($r['cost'],2)?></td></tr>
  <?php endforeach; ?>
</table>
<form method="post" class="grid grid-cols-3 gap-2 max-w-md">
  <input name="item" placeholder="Item" class="p-2 rounded text-black col-span-2">
  <input name="cost" placeholder="Cost" class="p-2 rounded text-black">
  <button class="bg-green-600 px-4 py-2 rounded col-span-3">Save</button>
</form>
</body></html>
