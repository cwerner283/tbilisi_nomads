<?php
// /public/hoods/show.php

require_once __DIR__ . '/../../config.php';
$pdo = db();

$slug = $_GET['slug'] ?? null;
if (!$slug) {
  http_response_code(400);
  echo "Missing neighborhood slug.";
  exit;
}

$stmt = $pdo->prepare("SELECT * FROM neighborhoods WHERE slug = ?");
$stmt->execute([$slug]);
$hood = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$hood) {
  http_response_code(404);
  echo "Neighborhood not found.";
  exit;
}

$overall = min(100, $hood['walkability_score']*3 + $hood['cost_score']*3 + min($hood['wifi_mbps'], 100)*0.3);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title><?= htmlspecialchars($hood['name']) ?> – Tbilisi Nomads</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-900 text-white min-h-screen">
  <div class="max-w-4xl mx-auto px-6 py-10">
    <a href="/hoods.php" class="text-gray-400 hover:text-white text-sm mb-4 inline-block">← Back to all neighborhoods</a>

    <div class="rounded-2xl overflow-hidden shadow-xl mb-6">
      <img src="<?= htmlspecialchars($hood['photo_url']) ?>"
           alt="<?= htmlspecialchars($hood['name']) ?>"
           class="w-full h-64 object-cover">
    </div>

    <h1 class="text-3xl font-bold mb-2"><?= htmlspecialchars($hood['name']) ?></h1>
    <p class="text-sm text-gray-400 mb-6">Tbilisi, Georgia</p>

    <?php if (!empty($hood['description'])): ?>
      <p class="text-base text-gray-200 mb-6"><?= nl2br(htmlspecialchars($hood['description'])) ?></p>
    <?php endif; ?>

    <div class="space-y-4 text-sm">
      <div class="flex items-center gap-2">⭐ Overall
        <div class="flex-1 h-2 bg-gray-700 rounded overflow-hidden">
          <div class="bg-yellow-400 h-2" style="width: <?= $overall ?>%"></div>
        </div>
      </div>
      <div class="flex items-center gap-2">💰 Cost
        <div class="flex-1 h-2 bg-gray-700 rounded overflow-hidden">
          <div class="bg-red-500 h-2" style="width: <?= 100 - ($hood['cost_score'] * 10) ?>%"></div>
        </div>
      </div>
      <div class="flex items-center gap-2">📡 Internet
        <div class="flex-1 h-2 bg-gray-700 rounded overflow-hidden">
          <div class="bg-green-400 h-2" style="width: <?= min($hood['wifi_mbps'],100) ?>%"></div>
        </div>
      </div>
      <div class="flex items-center gap-2">🚶 Walkability
        <div class="flex-1 h-2 bg-gray-700 rounded overflow-hidden">
          <div class="bg-blue-400 h-2" style="width: <?= $hood['walkability_score']*10 ?>%"></div>
        </div>
      </div>
      <div class="flex items-center gap-2">👮 Safety
        <div class="flex-1 h-2 bg-gray-700 rounded overflow-hidden">
          <div class="bg-green-300 h-2" style="width: <?= $hood['safety_score']*10 ?>%"></div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
