<?php
// /public/hoods.php

require_once __DIR__ . '/../config.php';
$pdo = db();

// Sort options
$allowed = ['wifi_mbps','walkability_score','cost_score','name'];
$sort = $_GET['sort'] ?? 'name';
if (!in_array($sort, $allowed)) {
    $sort = 'name';
}

// Fetch neighborhoods from DB
$hoods = $pdo
    ->query("SELECT * FROM neighborhoods ORDER BY $sort DESC")
    ->fetchAll(PDO::FETCH_ASSOC);

$isMapView = isset($_GET['view']) && $_GET['view'] === 'map';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>🏨 Tbilisi Neighborhoods – Tbilisi Nomads</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/leaflet@1.9.3/dist/leaflet.js"></script>
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.3/dist/leaflet.css" />
  <script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
  <script defer>
    // Password Generator Functions
    function generatePassword(length = 12, useUppercase = true, useNumbers = true, useSpecial = true) {
      let characters = 'abcdefghijklmnopqrstuvwxyz';
      if (useUppercase) characters += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
      if (useNumbers) characters += '0123456789';
      if (useSpecial) characters += '!@#$%^&*()_+-=[]{}|;:,.<>?';
      if (length < 1) return 'Length must be at least 1, dawg.';
      let password = '';
      for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * characters.length);
        password += characters[randomIndex];
      }
      return password;
    }

    function openPasswordModal() {
      const password = generatePassword(12, true, true, true);
      document.getElementById('generated-password').textContent = password;
      document.getElementById('password-modal').classList.remove('hidden');
    }

    function closePasswordModal() {
      document.getElementById('password-modal').classList.add('hidden');
    }

    function copyPassword() {
      const password = document.getElementById('generated-password').textContent;
      navigator.clipboard.writeText(password).then(() => {
        alert('Password copied to clipboard!');
      });
    }

    // Existing functions
    function openModal(id) {
      document.getElementById('modal-' + id).classList.remove('hidden');
    }
    function closeModal(id) {
      document.getElementById('modal-' + id).classList.add('hidden');
    }
    function toggleFavorite(id) {
      alert('Favorited neighborhood #' + id);
    }
    function initMap() {
      const map = L.map('map').setView([41.7151, 44.8271], 12);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
      }).addTo(map);

      <?php foreach ($hoods as $h):
        if (!empty($h['latitude']) && !empty($h['longitude'])):
          $color = $h['is_popular'] ? '#F59E0B' : '#10B981'; // Amber for popular, green for others
      ?>
      L.marker([<?= $h['latitude'] ?>, <?= $h['longitude'] ?>], {
        icon: L.divIcon({
          className: 'custom-icon',
          html: `<div style='background-color: ${'<?= $color ?>'}; width: 20px; height: 20px; border-radius: 50%; border: 2px solid white;'></div>`
        })
      })
        .addTo(map)
        .bindPopup("<strong><?= addslashes($h['name']) ?></strong><br>" +
                  "📶 <?= $h['wifi_mbps'] ?> Mbps<br>" +
                  "💰 Cost: <?= $h['cost_score'] ?>/10<br>" +
                  "🚶 Walk: <?= $h['walkability_score'] ?>/10<br>" +
                  "👮 Safety: <?= $h['safety_score'] ?>/10<br>" +
                  "<a href='/hoods/show.php?slug=<?= urlencode($h['slug']) ?>' class='text-blue-400'>Details</a>");
      <?php endif; endforeach; ?>
    }
    // Alternate Glovo/Bolt ad every 4 minutes
    document.addEventListener('DOMContentLoaded', function() {
      const adTile = document.getElementById('glovo-bolt-ad');
      const ads = [
        {
          href: 'https://glovoapp.com/?affiliate=tbilisinomads',
          img: 'https://i.postimg.cc/FHtJFz3Z/glovo.jpg',
          title: 'Glovo Tbilisi',
          subtitle: 'Food & Grocery Delivery in Tbilisi',
          cta: 'Order Now'
        },
        {
          href: 'https://bolt.eu/?affiliate=tbilisinomads',
          img: 'https://i.postimg.cc/YqLWwYG0/bolt.webp',
          title: 'Bolt Tbilisi',
          subtitle: 'Ride or Deliver in Tbilisi',
          cta: 'Ride Now'
        }
      ];
      let currentAd = 0;
      function updateAd() {
        adTile.querySelector('a').href = ads[currentAd].href;
        adTile.querySelector('img').src = ads[currentAd].img;
        adTile.querySelector('img').alt = ads[currentAd].title;
        adTile.querySelector('.ad-title').textContent = ads[currentAd].title;
        adTile.querySelector('.ad-subtitle').textContent = ads[currentAd].subtitle;
        adTile.querySelector('.ad-cta').textContent = ads[currentAd].cta;
        currentAd = (currentAd + 1) % ads.length;
      }
      updateAd(); // Initial display
      setInterval(updateAd, 240000); // Switch every 4 minutes
    });
  </script>
  <style>
    #map { height: 80vh; }
    @keyframes pulse {
      0% { transform: scale(1); }
      50% { transform: scale(1.05); }
      100% { transform: scale(1); }
    }
    .pulse:hover {
      animation: pulse 0.3s ease-in-out;
    }
    @keyframes bounce {
      0%, 100% { transform: translateY(0); }
      50% { transform: translateY(-5px); }
    }
    .bounce:hover {
      animation: bounce 0.4s ease-in-out;
    }
    .parallax {
      background-attachment: fixed;
      background-position: center;
      background-repeat: no-repeat;
      background-size: cover;
    }
  </style>
</head>
<body class="bg-gray-900 text-white min-h-screen" x-data="{ search: '', vibe: '' }">

<?php include __DIR__ . '/partials/header.php'; ?>

<!-- ===== Hero CTA ===== -->
<section class="parallax bg-[url('https://images.unsplash.com/photo-1559746696-5e4a1b81c04e')] bg-cover bg-center">
  <div class="backdrop-brightness-50 py-20">
    <div class="max-w-4xl mx-auto text-center px-6">
      <h1 class="text-5xl sm:text-6xl font-extrabold mb-6 tracking-tight">
        Tbilisi Neighborhoods <span class="text-amber-400">🔥 Find Your Vibe</span>
      </h1>
      <p class="text-xl sm:text-2xl text-gray-200 mb-10 leading-relaxed">
        Vake’s cafés, Old Tbilisi’s chaos, Saburtalo’s hustle—pick your hood with <span class="font-bold text-white">37,756+</span> nomads. From khachapuri joints to Fabrika coworking, we’ve got the scoop. <span class="text-amber-400">Gagimarjos!</span>
      </p>
      <a href="https://t.me/+TbilisiNomads" target="_blank" class="bg-amber-500 hover:bg-amber-400 px-10 py-5 rounded-lg font-bold text-gray-900 pulse text-lg">
        Join Telegram for Hood Hacks →
      </a>
    </div>
  </div>
</section>

<!-- ===== Neighborhood Filters & Listings ===== -->
<main class="max-w-6xl mx-auto px-6 py-12" x-data="{
  hoods: <?php echo json_encode($hoods); ?>,
  vibes: ['All', 'Hipster', 'Historic', 'Quiet', 'Party', 'Modern']
}">
  <?php if (!$isMapView): ?>
    <!-- Filters -->
    <div class="grid sm:grid-cols-4 gap-4 mb-8">
      <input type="text" x-model="search" placeholder="Search hoods (e.g., Vake, Old Tbilisi)..."
             class="p-3 rounded-lg text-black placeholder-gray-500 focus:ring-2 focus:ring-amber-400" />
      <select x-model="vibe" class="p-3 rounded-lg text-black">
        <template x-for="v in vibes" :key="v">
          <option x-text="v" :value="v"></option>
        </template>
      </select>
      <select @change="window.location.href='?sort=' + $event.target.value" class="p-3 rounded-lg text-black">
        <option value="name" <?= $sort === 'name' ? 'selected' : '' ?>>Sort by Name</option>
        <option value="wifi_mbps" <?= $sort === 'wifi_mbps' ? 'selected' : '' ?>>Sort by WiFi</option>
        <option value="walkability_score" <?= $sort === 'walkability_score' ? 'selected' : '' ?>>Sort by Walkability</option>
        <option value="cost_score" <?= $sort === 'cost_score' ? 'selected' : '' ?>>Sort by Affordability</option>
      </select>
      <a href="https://t.me/+TbilisiNomads" target="_blank" class="bg-amber-500 hover:bg-amber-400 px-4 py-3 rounded-lg font-bold text-gray-900 pulse text-center">
        Join Hood Chats
      </a>
    </div>

    <!-- Listings -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      <?php 
      $total_hoods = count($hoods);
      $ad1_position = 3; // After first 3 neighborhoods
      $ad2_position = max(4, $total_hoods - 3); // Before last 3, ensure at least 1 hood between ads
      $index = 0;
      foreach ($hoods as $h):
        if ($index == $ad1_position): ?>
          <a href="https://safetywing.com/?referenceID=26033743&utm_source=26033743&utm_medium=Ambassador" target="_blank" class="block">
            <div class="relative rounded-2xl overflow-hidden shadow-xl bg-black/70 aspect-[4/5] transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl">
              <img src="https://i.postimg.cc/XvcmJrh6/bird.webp" alt="SafetyWing Ad" class="w-full h-full object-cover">
              <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent p-4 flex flex-col justify-end">
                <div class="text-xl font-bold drop-shadow">SafetyWing Insurance</div>
                <div class="text-sm text-gray-300 drop-shadow">Nomad Insurance for Tbilisi Adventures</div>
                <div class="mt-2 flex justify-between text-sm">
                  <span class="bg-amber-500 text-gray-900 px-2 py-1 rounded">Sponsored</span>
                </div>
                <div class="flex justify-between mt-2">
                  <button class="text-sm px-3 py-1 bg-amber-500 hover:bg-amber-400 text-black font-bold rounded pulse">Get Covered</button>
                </div>
              </div>
            </div>
          </a>
        <?php endif;
        if ($index == $ad2_position): ?>
          <div id="glovo-bolt-ad" class="block">
            <a href="https://glovoapp.com/?affiliate=tbilisinomads" target="_blank" class="block">
              <div class="relative rounded-2xl overflow-hidden shadow-xl bg-black/70 aspect-[4/5] transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl">
                <img src="https://i.postimg.cc/FHtJFz3Z/glovo.jpg" alt="Glovo Tbilisi" class="w-full h-full object-cover">
                <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent p-4 flex flex-col justify-end">
                  <div class="text-xl font-bold drop-shadow ad-title">Glovo Tbilisi</div>
                  <div class="text-sm text-gray-300 drop-shadow ad-subtitle">Food & Grocery Delivery in Tbilisi</div>
                  <div class="mt-2 flex justify-between text-sm">
                    <span class="bg-amber-500 text-gray-900 px-2 py-1 rounded">Sponsored</span>
                  </div>
                  <div class="flex justify-between mt-2">
                    <button class="text-sm px-3 py-1 bg-amber-500 hover:bg-amber-400 text-black font-bold rounded pulse ad-cta">Order Now</button>
                  </div>
                </div>
              </div>
            </a>
          </div>
        <?php endif; ?>
        <a href="/hoods/show.php?slug=<?= urlencode($h['slug']) ?>" class="block">
          <div class="relative rounded-2xl overflow-hidden shadow-xl bg-black/70 aspect-[4/5] transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl">
            <img src="<?= htmlspecialchars($h['photo_url'] ?? 'https://via.placeholder.com/400x300?text=' . urlencode($h['name'])) ?>"
                 alt="<?= htmlspecialchars($h['name']) ?>"
                 class="w-full h-full object-cover">
            <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent p-4 flex flex-col justify-end">
              <div class="text-xl font-bold drop-shadow"><?= htmlspecialchars($h['name']) ?></div>
              <div class="text-sm text-gray-300 drop-shadow">Tbilisi, Georgia</div>
              <div class="mt-2 flex justify-between text-sm">
                <span class="flex items-center gap-1">📶 <?= $h['wifi_mbps'] ?> Mbps</span>
                <span>💰 <?= $h['cost_score'] ?>/10</span>
              </div>
              <div class="flex justify-between text-sm mt-1">
                <span>🚶 Walk: <?= $h['walkability_score'] ?>/10</span>
                <?php if ($h['is_popular']): ?><span class="text-amber-400 font-semibold">🔥 Nomad Fave</span><?php endif; ?>
              </div>
              <div class="flex justify-between mt-2">
                <button onclick="openModal(<?= $h['id'] ?>); event.preventDefault()" class="text-sm px-3 py-1 bg-white/10 hover:bg-white/20 rounded">Details</button>
                <button onclick="toggleFavorite(<?= $h['id'] ?>); event.preventDefault()" class="text-sm px-3 py-1 bg-amber-500 text-black font-bold rounded">★</button>
              </div>
            </div>
          </div>
        </a>
        <!-- Modal -->
        <div id="modal-<?= $h['id'] ?>" class="hidden fixed inset-0 z-50 bg-black/80 backdrop-blur flex items-center justify-center p-4">
          <div class="bg-gray-900 rounded-xl max-w-lg w-full shadow-2xl p-6 relative">
            <button onclick="closeModal(<?= $h['id'] ?>)" class="absolute top-2 right-4 text-white text-xl">✕</button>
            <h2 class="text-2xl font-bold mb-2"><?= htmlspecialchars($h['name']) ?></h2>
            <?php if (!empty($h['description'])): ?>
              <p class="text-sm text-gray-300 mb-4"><?= htmlspecialchars($h['description']) ?></p>
            <?php else: ?>
              <p class="text-sm text-gray-300 mb-4">No description available.</p>
            <?php endif; ?>
            <div class="space-y-3 text-sm">
              <?php $overall = min(100, $h['walkability_score']*3 + $h['cost_score']*3 + min($h['wifi_mbps'], 100)*0.3); ?>
              <div class="flex items-center gap-2">⭐ Overall
                <div class="flex-1 h-2 bg-gray-700 rounded overflow-hidden">
                  <div class="bg-amber-400 h-2" style="width: <?= $overall ?>%"></div>
                </div>
              </div>
              <div class="flex items-center gap-2">💰 Cost
                <div class="flex-1 h-2 bg-gray-700 rounded overflow-hidden">
                  <div class="bg-red-500 h-2" style="width: <?= 100 - ($h['cost_score'] * 10) ?>%"></div>
                </div>
              </div>
              <div class="flex items-center gap-2">📱 Internet
                <div class="flex-1 h-2 bg-gray-700 rounded overflow-hidden">
                  <div class="bg-green-400 h-2" style="width: <?= min($h['wifi_mbps'], 100) ?>%"></div>
                </div>
              </div>
              <div class="flex items-center gap-2">🚶 Walkability
                <div class="flex-1 h-2 bg-gray-700 rounded overflow-hidden">
                  <div class="bg-blue-400 h-2" style="width: <?= $h['walkability_score']*10 ?>%"></div>
                </div>
              </div>
              <div class="flex items-center gap-2">👮 Safety
                <div class="flex-1 h-2 bg-gray-700 rounded overflow-hidden">
                  <div class="bg-green-300 h-2" style="width: <?= $h['safety_score']*10 ?>%"></div>
                </div>
              </div>
            </div>
            <a href="/hoods/show.php?slug=<?= urlencode($h['slug']) ?>" class="text-amber-400 hover:text-amber-300 underline mt-4 inline-block">View full page →</a>
            <a href="https://t.me/+TbilisiNomads?hood=<?= urlencode($h['slug']) ?>" target="_blank" class="text-amber-400 hover:text-amber-300 underline mt-2 inline-block">Join Hood Chat</a>
          </div>
        </div>
      <?php 
        $index++;
      endforeach; ?>
    </div>

    <!-- Password Generator Button and Modal -->
    <button onclick="openPasswordModal()" class="bg-amber-500 hover:bg-amber-400 px-6 py-3 rounded-lg font-bold text-gray-900 pulse text-lg mt-8">
      Generate Secure Password
    </button>
    <div id="password-modal" class="hidden fixed inset-0 z-50 bg-black/80 backdrop-blur flex items-center justify-center p-4">
      <div class="bg-gray-900 rounded-xl max-w-lg w-full shadow-2xl p-6 relative">
        <button onclick="closePasswordModal()" class="absolute top-2 right-4 text-white text-xl">✕</button>
        <h2 class="text-2xl font-bold mb-2">Your Generated Password</h2>
        <p id="generated-password" class="text-xl text-amber-400 mb-4"></p>
        <button onclick="copyPassword()" class="bg-amber-500 hover:bg-amber-400 px-4 py-2 rounded text-gray-900">Copy to Clipboard</button>
      </div>
    </div>

  <?php else: ?>
    <div id="map" class="rounded-xl overflow-hidden"></div>
    <script>window.onload = initMap;</script>
  <?php endif; ?>
</main>

<!-- ===== Nomad Hacks ===== -->
<section class="max-w-5xl mx-auto px-6 py-12">
  <h2 class="text-3xl font-bold text-center mb-8">Hood-Hunting Hacks 🔥</h2>
  <div class="grid sm:grid-cols-3 gap-6 mb-12">
    <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200 bounce">
      <span class="text-3xl">📶</span>
      <h3 class="text-xl font-semibold mt-2 mb-1">WiFi That Works</h3>
      <p class="text-gray-300">Magti vs. Silknet? Test speeds in #HoodHacks on Telegram.</p>
    </div>
    <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200 bounce">
      <span class="text-3xl">🥟</span>
      <h3 class="text-xl font-semibold mt-2 mb-1">Khachapuri Spots</h3>
      <p class="text-gray-300">Find the cheesiest joints in #Foodies. Old Tbilisi’s a gem.</p>
    </div>
    <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200 bounce">
      <span class="text-3xl">🚗</span>
      <h3 class="text-xl font-semibold mt-2 mb-1">Bolt Accessibility</h3>
      <p class="text-gray-300">Cheap rides to Fabrika? Get tips in #NomadLife.</p>
    </div>
  </div>
</section>

<!-- ===== Telegram Teaser ===== -->
<section class="bg-gray-850 py-16">
  <div class="max-w-5xl mx-auto px-6 text-center">
    <h2 class="text-4xl font-bold mb-6">Unlock Tbilisi’s Hood Secrets 🔥</h2>
    <p class="text-xl text-gray-200 mb-8">
      Apartment tips, hidden cafés, Rustaveli vibes—join <span class="font-semibold">Telegram #HoodHacks</span> for insider scoops from locals & nomads. Vake or Old Tbilisi? We’ll help you pick. <span class="text-amber-400">Gagimarjos!</span>
    </p>
    <div class="grid sm:grid-cols-3 gap-6 mb-10">
      <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200 bounce">
        <span class="text-3xl">🏠</span>
        <h3 class="text-xl font-semibold mt-2">Apartment Hacks</h3>
        <p class="text-gray-300">Find flats in Vake or Saburtalo via #HoodHacks.</p>
      </div>
      <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200 bounce">
        <span class="text-3xl">☕</span>
        <h3 class="text-xl font-semibold mt-2">Hidden Cafés</h3>
        <p class="text-gray-300">Best work spots in Old Tbilisi. Ask #Foodies.</p>
      </div>
      <div class="bg-gray-800 rounded-xl p-6 hover:bg-gray-750 transition duration-200 bounce">
        <span class="text-3xl">🤝</span>
        <h3 class="text-xl font-semibold mt-2">Local Connections</h3>
        <p class="text-gray-300">Meet nomads & locals in #NomadLife.</p>
      </div>
    </div>
    <a href="https://t.me/+TbilisiNomads" target="_blank" class="bg-amber-500 hover:bg-amber-400 px-10 py-5 rounded-lg font-bold text-gray-900 pulse text-lg">
      Join Telegram for Hood Chats →
    </a>
  </div>
</section>

<!-- ===== Footer ===== -->
<footer class="bg-gray-800 text-gray-400 text-sm py-10">
  <div class="max-w-5xl mx-auto px-6">
    <div class="grid sm:grid-cols-3 gap-6 mb-6">
      <div>
        <h4 class="text-white font-semibold mb-2">Tbilisi Nomads</h4>
        <p>Inspired by Nomad List, built for Georgia’s wild heart. Locals & nomads unite!</p>
      </div>
      <div>
        <h4 class="text-white font-semibold mb-2">Quick Links</h4>
        <ul class="space-y-1">
          <li><a href="/index.php" class="hover:text-amber-400">Home</a></li>
          <li><a href="/community.php" class="hover:text-amber-400">Community</a></li>
          <li><a href="/jobs.php" class="hover:text-amber-400">Jobs</a></li>
          <li><a href="/events.php" class="hover:text-amber-400">Events</a></li>
        </ul>
      </div>
      <div>
        <h4 class="text-white font-semibold mb-2">Stay Updated</h4>
        <form class="flex gap-2">
          <input type="email" placeholder="Your email…" class="flex-1 p-2 rounded text-black">
          <button class="bg-amber-500 hover:bg-amber-400 px-4 py-2 rounded text-gray-900">Subscribe</button>
        </form>
      </div>
    </div>
    <p class="text-center">© <?= date('Y') ?> Tbilisi Nomads. Crafted with ❤️ for remote workers.</p>
  </div>
</footer>

</body>
</html>